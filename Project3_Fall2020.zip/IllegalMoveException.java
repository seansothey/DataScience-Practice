class IllegalMoveException extends RuntimeException
{
    IllegalMoveException(String msg)
    {super(msg);}
}